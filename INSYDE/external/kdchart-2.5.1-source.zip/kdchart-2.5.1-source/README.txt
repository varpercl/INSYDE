Welcome to KD Chart 2, Klaralvdalens Datakonsult's charting engine for Qt!

Please refer to the license file for conditions of use.

After reading the introductory overview files in doc/
you will find more information at three places:

detailed browsable API reference:   doc/refman/index.html
                              or:   http://docs.kdab.com/kdchart/2.5.1/
programmers manual with examples:   doc/manual/kdchart.pdf
our sorted example programs:        examples/

In case of additional questions during evaluation or use of
KD Chart please contact our technical support via customers.kdab.com.


We thank you for your interest in KD Chart and we are here
to assist you if the documentation leaves open questions or
if you just need some help with finding the best way in which
to realize your charting ideas.

The KDAB KD Chart Support Team.
